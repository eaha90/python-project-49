### Hexlet tests and linter status:
[![Actions Status](https://github.com/eaha90/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/eaha90/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/ab977d1540b4e4dfc707/maintainability)](https://codeclimate.com/github/eaha90/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/509283/thumb.svg)](https://asciinema.org/a/pqO3K8bpU1h7rnU0BmMe88HXf)
